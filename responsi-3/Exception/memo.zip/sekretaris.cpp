#include "sekretaris.h"
#include <iostream>

//energi
//tinta
//kertas
//memolength
//memo

Sekretaris::Sekretaris(){ // benar
    kertas = KERTAS_DEFAULT;
    tinta = TINTA_DEFAULT;
    energi = ENERGI_MAX;
    memoLength = 0;
    memo = new Memo[kertas];
}

Sekretaris::Sekretaris(int kertas, int tinta){ // benar
    this->kertas = kertas;
    this->tinta = tinta;
    this->energi = ENERGI_MAX;
    this->memoLength = 0;
    memo = new Memo[kertas];
}

Sekretaris::~Sekretaris(){ // benar
    delete [] memo;
}

void Sekretaris::pakaiKertas(){ // benar
    kertas--;
    if(kertas < 0){
        throw KertasHabisException();
    }
}

void Sekretaris::pakaiTinta(int num){ // benar
    tinta -= num;
    if(tinta < 0){
        throw TintaKurangException();
    }
}

void Sekretaris::pakaiEnergi(){ // benar
    energi--;
    if(energi < 0){
        throw EnergiHabisException();
    }
}

void Sekretaris::batalPakaiKertas(){
    kertas++;
}

void Sekretaris::batalPakaiTinta(int num){
    tinta += num;
}

void Sekretaris::batalPakaiEnergi(){
    energi++;
}

void Sekretaris::isiTinta(int num){
    tinta += num;
}

void Sekretaris::isiKertas(int num){
    kertas += num;
}

void Sekretaris::istirahat(){
    energi = ENERGI_MAX;
}

void Sekretaris::buatMemo(string pesan, string untuk){
    try{
        Memo m(pesan, untuk);
        pakaiKertas();
        pakaiTinta(pesan.length());
        pakaiEnergi();
        memo[memoLength] = m;
        cout<<"Memo ["<<memoLength+1<<"] untuk "<<untuk<<" berhasil dibuat"<<endl;
        memoLength++;
    }catch(PesanKepanjanganException e){
        cout<<e.what()<<", segera isi kertas"<<endl;
    }catch(KertasHabisException e){
        batalPakaiKertas();
        cout<<e.what()<<", segera isi kertas"<<endl;
    }catch(TintaKurangException e){
        batalPakaiKertas();
        batalPakaiTinta(pesan.length());
        cout<<e.what()<<", segera isi tinta"<<endl;
    }catch(EnergiHabisException e){
        batalPakaiKertas();
        batalPakaiTinta(pesan.length());
        batalPakaiEnergi();
        cout<<e.what()<<", segera istirahat"<<endl;
    }
}

void Sekretaris::printStatus(){
    cout<<"Status"<<endl;
    cout<<" Energi : "<<energi<<endl;
    cout<<" Tinta : "<<tinta<<endl;
    cout<<" Kertas : "<<kertas<<endl;
    cout<<" Memo : "<<memoLength<<endl;
    for(int i = 0; i < memoLength; i++){
        cout<<"  Memo ["<<i+1<<"]"<<endl;
        cout<<"   Pesan : "<<memo[i].getPesan()<<endl;
        cout<<"   Untuk : "<<memo[i].getUntuk()<<endl;
    }
}